# OpenVPN Scramble Obfuscate Android

کلاینت سبک Android برای:
- Import فایل `.ovpn`
- اتصال و قطع اتصال OpenVPN
- پشتیبانی Tunnelblick XOR/Scramble با حالت `obfuscate`

موتور پایه از پروژه متن‌باز `lawtancool/ics-openvpn-xor` استفاده می‌کند. این پروژه fork از OpenVPN for Android است و پشتیبانی Tunnelblick obfuscation patch را اضافه کرده است.

## ساخت APK

این پروژه سورس کامل موتور را در خود repository کپی نمی‌کند؛ GitHub Actions سورس upstream را دریافت کرده و همان سورس را build می‌کند.

در GitHub:
1. یک repository بساز.
2. فایل‌های این ZIP را داخل آن قرار بده.
3. به Actions برو.
4. `Build OpenVPN Scramble APK` را اجرا کن.
5. APK را از Artifacts دریافت کن.

## Scramble

حالت موردنظر:
`obfuscate`

برای کارکرد واقعی، سمت سرور OpenVPN نیز باید با همان Tunnelblick XOR patch سازگار باشد.

## مجوز

کد upstream دارای مجوز GPL و شرایط اضافی پروژه OpenVPN for Android است. پیش از توزیع عمومی، LICENSEهای upstream را نگه دار.

Upstream:
https://github.com/lawtancool/ics-openvpn-xor

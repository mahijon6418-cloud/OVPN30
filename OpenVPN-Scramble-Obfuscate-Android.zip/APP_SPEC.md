# مشخصات نسخه

UI فقط برای:
1. Import `.ovpn`
2. انتخاب پروفایل
3. Connect
4. Disconnect
5. نمایش وضعیت/لاگ

Scramble:
- فقط `obfuscate`
- بدون xormask
- بدون xorptrpos
- بدون reverse
- بدون obfs3

نکته فنی:
`obfuscate` باید توسط OpenVPN engine دارای Tunnelblick XOR patch اجرا شود؛ صرفاً اضافه‌کردن یک گزینه در UI کافی نیست.
